﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RestaurantManager.Modèle.BDD;

namespace TestRestaurantManager
{
    [TestClass]
    public class TestBDD
    {
        [TestMethod]
        public void testRecette()
        {
            
        }
    }
}
